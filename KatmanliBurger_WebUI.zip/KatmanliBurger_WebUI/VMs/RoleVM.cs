﻿namespace KatmanliBurger_WebUI.VMs
{
    public class RoleVM
    {
        public string Name { get; set; }
        public DateTime CreatedDate { get; set; } = DateTime.Now;
    }
}
