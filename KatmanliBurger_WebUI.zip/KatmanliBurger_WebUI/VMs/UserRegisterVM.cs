﻿namespace KatmanliBurger_WebUI.VMs
{
    public class UserRegisterVM
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Adress { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }

    }
}
