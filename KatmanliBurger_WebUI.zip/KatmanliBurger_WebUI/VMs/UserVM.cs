﻿namespace KatmanliBurger_WebUI.VMs
{
    public class UserVM
    {
        public string Password { get; set; }
        public string Email { get; set; }
    }
}
