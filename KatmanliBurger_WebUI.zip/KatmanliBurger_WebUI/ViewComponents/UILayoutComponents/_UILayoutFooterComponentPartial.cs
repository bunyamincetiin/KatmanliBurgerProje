﻿using Microsoft.AspNetCore.Mvc;

namespace KatmanliBurger_UI.ViewComponents.UILayoutComponents
{
    public class _UILayoutFooterComponentPartial:ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            return View();
        }
    }
}
