﻿using Microsoft.AspNetCore.Mvc;

namespace KatmanliBurger_UI.ViewComponents.UILayoutComponents
{
    public class _UILayoutScriptComponentPartial:ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            return View();
        }
    }
}
